﻿#include "Engine.h"

const int Global_Scale = 3;                     // Глобальный масштаб
const int Brick_Width = 15;                     // Ширина кирпича
const int Brick_Height = 7;                     // Высота кирпича
const int Cell_Width = Brick_Width + 1;         // Ширина ячейки (16 px)
const int Cell_Height = Brick_Height + 1;       // Высота ячейки (17 px)
const int Lelvel_X_Offset = 8;                  // Смещение поле по Х 
const int Lelvel_Y_Offset = 6;                  // Смещение поле по Y 
const int Circle_Size = 7;                      // Размер круга платформы

int Inner_Width = 21;                           // Ширина платформы

HPEN Highligh_Pen, Brick_Red_Pen, Brick_Blue_Pen, Platgorm_Circle_Pen, Platgorm_Inner_Pen;   // Создаем карандаш
HBRUSH Brick_Red_Brush, Brick_Blue_Brush, Platgorm_Circle_Brush, Platgorm_Inner_Brush;       // Создаем кисть

char Level_01[14][12] =                         // Отрисовка расположение кирпича и тип кирпича
{
   0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
   0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
   1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
   1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
   2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
   2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
   1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
   1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
   2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
   2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
   0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
   0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
   0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
   0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
};

enum EBrick_Type: char
{                                               // None - 0, Blue - 1, Red - 2
   EBT_None,                                      
   EBT_Blue,
   EBT_Red
};
//--------------------------------------------------------------------------------------------------------------
void Create_Pen_Brush(unsigned char r, unsigned char g, unsigned char b, HPEN &pen, HBRUSH &brush)
{
   pen = CreatePen(PS_SOLID, 0, RGB(r, g, b));  // Создал карандаш для окраски кирпича
   brush = CreateSolidBrush(RGB(r, g, b));      // Создал кисть для окраски кирпича
}
//--------------------------------------------------------------------------------------------------------------
void Init()
{// Настройка игры при старте  
   Highligh_Pen = CreatePen(PS_SOLID, 0, RGB(0, 255, 255));
   Create_Pen_Brush(85, 255, 255, Brick_Blue_Pen, Brick_Blue_Brush);
   Create_Pen_Brush(255, 85, 85, Brick_Red_Pen, Brick_Red_Brush);
   Create_Pen_Brush(151, 0, 0, Platgorm_Circle_Pen, Platgorm_Circle_Brush);
   Create_Pen_Brush(0, 128, 192, Platgorm_Inner_Pen, Platgorm_Inner_Brush);
}
//--------------------------------------------------------------------------------------------------------------
void Draw_Brick(HDC hdc, int x, int y , char brick_type)
{// Вывод кирпича                                                    
   HPEN pen;
   HBRUSH brush;

   switch (brick_type)
   {
   case EBT_None:
      return;

   case EBT_Blue:
      pen = Brick_Blue_Pen; 
      brush = Brick_Blue_Brush;  
      break;

   case EBT_Red:
      pen = Brick_Red_Pen;
      brush = Brick_Red_Brush;
      break;

   default:
      return;
   }
   SelectObject(hdc, pen);    // Окрашиваем карандашом(pen) наш объект(кирпич - рамка)
   SelectObject(hdc, brush);  // Окрашиваем кистью(brush) наш объект(кирпич - тело)

   RoundRect(hdc, x * Global_Scale, y * Global_Scale, (x + Brick_Width) * Global_Scale, 
      (y + Brick_Height) * Global_Scale, 2 * Global_Scale, 2 * Global_Scale);      // Отрисовка прямоугольника  c закругленными углами
}
//--------------------------------------------------------------------------------------------------------------
void Draw_Level(HDC hdc)
{ // Вывод всех кирпичей
   int i, j;

   for (i = 0; i < 14; i++) 
      for (j = 0; j < 12; j++) 
         Draw_Brick(hdc, Lelvel_X_Offset + j * Cell_Width, Lelvel_Y_Offset + i * Cell_Height, Level_01[i][j]);
}
//--------------------------------------------------------------------------------------------------------------
void Draw_Platform(HDC hdc, int x, int y)                                          
{// Рисую платформу
   // 1. Рисуем боковые шарики
   SelectObject(hdc, Platgorm_Circle_Pen);    
   SelectObject(hdc, Platgorm_Circle_Brush);

   Ellipse(hdc, x * Global_Scale, y * Global_Scale, (x + Circle_Size) * Global_Scale, (y + Circle_Size) * Global_Scale);
   Ellipse(hdc, (x + Inner_Width) * Global_Scale, y * Global_Scale, (x + Circle_Size + Inner_Width) * Global_Scale, (y + Circle_Size) * Global_Scale);
   
   // 2. Рисуем блик на шарике
   SelectObject(hdc, Highligh_Pen);    
   
   Arc(hdc, (x + 1) * Global_Scale, (y + 1) * Global_Scale, (x + Circle_Size - 1) * Global_Scale,
            (y + Circle_Size - 1) * Global_Scale, (x + 1 + 1) * Global_Scale, (y + 1) * Global_Scale,
            (x + 1) * Global_Scale, (y + 2 + 2) * Global_Scale);
   
   // 3. Рисуем платформу(средняя часть)
   SelectObject(hdc, Platgorm_Inner_Pen);    
   SelectObject(hdc, Platgorm_Inner_Brush); 

   RoundRect(hdc, (x + 4) * Global_Scale, (y + 1) * Global_Scale, (x + 4 + Inner_Width - 1) * Global_Scale, (y + 1 + 5) * Global_Scale, 3 * Global_Scale, 3 * Global_Scale);
}
//--------------------------------------------------------------------------------------------------------------
void Draw_Frame(HDC hdc)                                          
{// Отрисовка экрана игры                                                                 
   Draw_Level(hdc);
   Draw_Platform(hdc, 70, 150);
}
//--------------------------------------------------------------------------------------------------------------
