#pragma once

#include <Windows.h>

void Init();
void Draw_Frame(HDC hdc);