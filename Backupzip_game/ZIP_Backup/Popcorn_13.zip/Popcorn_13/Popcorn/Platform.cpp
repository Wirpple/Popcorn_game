﻿#include "Platform.h"

//--------------------------------------------------------------------------------------------------------------
AsPlatform::AsPlatform()
   :Inner_Width(21), X_Pos(85), X_Pos_Step(AsConfig::Global_Scale * 2), Width(28), Platform_Rect{}, Prev_Platform_Rect{}, 
   Platgorm_Inner_Pen(0), Platgorm_Circle_Pen(0), Highligh_Pen(0), Platgorm_Inner_Brush(0), Platgorm_Circle_Brush(0)
{
}
//--------------------------------------------------------------------------------------------------------------
void AsPlatform::Init()
{
   Highligh_Pen = CreatePen(PS_SOLID, 0, RGB(0, 255, 255));
   AsConfig::Create_Pen_Brush(151, 0, 0, Platgorm_Circle_Pen, Platgorm_Circle_Brush);
   AsConfig::Create_Pen_Brush(0, 128, 192, Platgorm_Inner_Pen, Platgorm_Inner_Brush);
}
//--------------------------------------------------------------------------------------------------------------
void AsPlatform::Redraw_Platform(HWND hwnd)
{  
   Prev_Platform_Rect = Platform_Rect;

   Platform_Rect.left = X_Pos * AsConfig::Global_Scale;
   Platform_Rect.top = AsConfig::Y_Pos * AsConfig::Global_Scale;
   Platform_Rect.right = Platform_Rect.left + Width * AsConfig::Global_Scale;
   Platform_Rect.bottom = Platform_Rect.top + Platform_Height * AsConfig::Global_Scale;

   InvalidateRect(hwnd, &Prev_Platform_Rect, FALSE);
   InvalidateRect(hwnd, &Platform_Rect, FALSE);
}
//------------------------------------------------------------------------------------------------------------- 
void AsPlatform::Draw(HDC hdc, RECT &paint_area, HPEN bg_pen, HBRUSH bg_brush)                                          
{// Рисую платформу
   int x = X_Pos;
   int y = AsConfig::Y_Pos;

   RECT intersection_rect;

   if (!IntersectRect(&intersection_rect, &paint_area, &Platform_Rect))
      return;

   SelectObject(hdc, bg_pen);    
   SelectObject(hdc, bg_brush);

   Rectangle(hdc, Prev_Platform_Rect.left, Prev_Platform_Rect.top, Prev_Platform_Rect.right, Prev_Platform_Rect.bottom);

   // 1. Рисуем боковые шарики
   SelectObject(hdc, Platgorm_Circle_Pen);    
   SelectObject(hdc, Platgorm_Circle_Brush);

   Ellipse(hdc, x * AsConfig::Global_Scale, y * AsConfig::Global_Scale, (x + Circle_Size) * AsConfig::Global_Scale, (y + Circle_Size) * AsConfig::Global_Scale);
   Ellipse(hdc, (x + Inner_Width) * AsConfig::Global_Scale, y * AsConfig::Global_Scale, (x + Circle_Size + Inner_Width) * AsConfig::Global_Scale, (y + Circle_Size) * AsConfig::Global_Scale);

   // 2. Рисуем блик на шарике
   SelectObject(hdc, Highligh_Pen);    

   Arc(hdc, (x + 1) * AsConfig::Global_Scale, (y + 1) * AsConfig::Global_Scale, (x + Circle_Size - 1) * AsConfig::Global_Scale,
      (y + Circle_Size - 1) * AsConfig::Global_Scale, (x + 1 + 1) * AsConfig::Global_Scale, (y + 1) * AsConfig::Global_Scale,
      (x + 1) * AsConfig::Global_Scale, (y + 2 + 2) * AsConfig::Global_Scale);

   // 3. Рисуем платформу(средняя часть)
   SelectObject(hdc, Platgorm_Inner_Pen);    
   SelectObject(hdc, Platgorm_Inner_Brush); 

   RoundRect(hdc, (x + 4) * AsConfig::Global_Scale, (y + 1) * AsConfig::Global_Scale, (x + 4 + Inner_Width - 1) * AsConfig::Global_Scale, (y + 1 + 5) * AsConfig::Global_Scale, 3 * AsConfig::Global_Scale, 3 * AsConfig::Global_Scale);
}
//--------------------------------------------------------------------------------------------------------------



