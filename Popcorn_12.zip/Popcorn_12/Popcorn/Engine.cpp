﻿#include "Engine.h"

//APlatform
//--------------------------------------------------------------------------------------------------------------
AsPlatform::AsPlatform()
   :Inner_Width(21), X_Pos(85), X_Pos_Step(AsConfig::Global_Scale * 2), Width(28), Platform_Rect{}, Prev_Platform_Rect{}, 
    Platgorm_Inner_Pen(0), Platgorm_Circle_Pen(0), Highligh_Pen(0), Platgorm_Inner_Brush(0), Platgorm_Circle_Brush(0)
{
}
//--------------------------------------------------------------------------------------------------------------
void AsPlatform::Init()
{
   Highligh_Pen = CreatePen(PS_SOLID, 0, RGB(0, 255, 255));
   AsConfig::Create_Pen_Brush(151, 0, 0, Platgorm_Circle_Pen, Platgorm_Circle_Brush);
   AsConfig::Create_Pen_Brush(0, 128, 192, Platgorm_Inner_Pen, Platgorm_Inner_Brush);
}
//--------------------------------------------------------------------------------------------------------------
void AsPlatform::Redraw_Platform(AsEngine *engine)
{  
   Prev_Platform_Rect = Platform_Rect;

   Platform_Rect.left = X_Pos * AsConfig::Global_Scale;
   Platform_Rect.top = AsConfig::Y_Pos * AsConfig::Global_Scale;
   Platform_Rect.right = Platform_Rect.left + Width * AsConfig::Global_Scale;
   Platform_Rect.bottom = Platform_Rect.top + Platform_Height * AsConfig::Global_Scale;

   InvalidateRect(engine->Hwnd, &Prev_Platform_Rect, FALSE);
   InvalidateRect(engine->Hwnd, &Platform_Rect, FALSE);
}
//------------------------------------------------------------------------------------------------------------- 
void AsPlatform::Draw(HDC hdc, RECT &paint_area, AsEngine *engine)                                          
{// Рисую платформу
   int x = X_Pos;
   int y = AsConfig::Y_Pos;

   RECT intersection_rect;

   if (!IntersectRect(&intersection_rect, &paint_area, &Platform_Rect))
      return;

   SelectObject(hdc, engine->BG_Pen);    
   SelectObject(hdc, engine->BG_Brush);

   Rectangle(hdc, Prev_Platform_Rect.left, Prev_Platform_Rect.top, Prev_Platform_Rect.right, Prev_Platform_Rect.bottom);

   // 1. Рисуем боковые шарики
   SelectObject(hdc, Platgorm_Circle_Pen);    
   SelectObject(hdc, Platgorm_Circle_Brush);

   Ellipse(hdc, x * AsConfig::Global_Scale, y * AsConfig::Global_Scale, (x + Circle_Size) * AsConfig::Global_Scale, (y + Circle_Size) * AsConfig::Global_Scale);
   Ellipse(hdc, (x + Inner_Width) * AsConfig::Global_Scale, y * AsConfig::Global_Scale, (x + Circle_Size + Inner_Width) * AsConfig::Global_Scale, (y + Circle_Size) * AsConfig::Global_Scale);

   // 2. Рисуем блик на шарике
   SelectObject(hdc, Highligh_Pen);    

   Arc(hdc, (x + 1) * AsConfig::Global_Scale, (y + 1) * AsConfig::Global_Scale, (x + Circle_Size - 1) * AsConfig::Global_Scale,
      (y + Circle_Size - 1) * AsConfig::Global_Scale, (x + 1 + 1) * AsConfig::Global_Scale, (y + 1) * AsConfig::Global_Scale,
      (x + 1) * AsConfig::Global_Scale, (y + 2 + 2) * AsConfig::Global_Scale);

   // 3. Рисуем платформу(средняя часть)
   SelectObject(hdc, Platgorm_Inner_Pen);    
   SelectObject(hdc, Platgorm_Inner_Brush); 

   RoundRect(hdc, (x + 4) * AsConfig::Global_Scale, (y + 1) * AsConfig::Global_Scale, (x + 4 + Inner_Width - 1) * AsConfig::Global_Scale, (y + 1 + 5) * AsConfig::Global_Scale, 3 * AsConfig::Global_Scale, 3 * AsConfig::Global_Scale);
}
//--------------------------------------------------------------------------------------------------------------



// AsEngine
//--------------------------------------------------------------------------------------------------------------
AsEngine::AsEngine()
   :Hwnd(0), BG_Pen(0), BG_Brush(0)
{
}
//--------------------------------------------------------------------------------------------------------------
void AsEngine::Init_Engine(HWND hwnd)
{// Настройка игры при старте  

   Hwnd = hwnd;

   AsConfig::Create_Pen_Brush(15, 63, 31, BG_Pen, BG_Brush);
   
   Level.Init();
   Ball.Init();
   Platform.Init();
   Border.Init();

   Platform.Redraw_Platform(this);

   SetTimer(Hwnd, Timer_ID, 50, 0);
}
//--------------------------------------------------------------------------------------------------------------
void AsEngine::Draw(HDC hdc, RECT &paint_area)                                          
{// Отрисовка экрана игры                                                                 
   
   RECT intersection_rect{};

   Level.Draw(hdc, paint_area);
   Platform.Draw(hdc, paint_area, this);
   Ball.Draw(hdc, paint_area, BG_Pen, BG_Brush);
   Border.Draw(hdc, paint_area, BG_Pen, BG_Brush);

   //if (IntersectRect(&intersection_rect, &paint_area, &Ball.Ball_Rect))
   //   Ball.Draw(hdc, paint_area, this);
   
   //int i;
   //
   //for (i = 0; i < 16; i++)
   //{
   //   Draw_Brick_Letter(hdc, 20 + i * AsConfig::Cell_Width * Global_Scale, 100, EBT_Blue, ELT_O, i);
   //   Draw_Brick_Letter(hdc, 20 + i * AsConfig::Cell_Width * Global_Scale, 130, EBT_Red, ELT_O, i);
   //}
}
//--------------------------------------------------------------------------------------------------------------
int AsEngine::On_Key_Down(EKey_Type key_type)
{
   switch (key_type)
   {
   case EKT_Left:
      Platform.X_Pos -= Platform.X_Pos_Step;

      if (Platform.X_Pos <= AsConfig::Border_X_Offset)
         Platform.X_Pos = AsConfig::Border_X_Offset;

      Platform.Redraw_Platform(this);
      break;

   case EKT_Right:
      Platform.X_Pos += Platform.X_Pos_Step;

      if (Platform.X_Pos >= AsConfig::Max_X_Pos - Platform.Width + 1)
         Platform.X_Pos = AsConfig::Max_X_Pos - Platform.Width + 1;

      Platform.Redraw_Platform(this);
      break;

   case EKT_Space:
      break;

   default:
      break;
   }
   return 0;
}
//--------------------------------------------------------------------------------------------------------------
int AsEngine::On_Timer()
{
   Ball.Move(Hwnd, &Level, Platform.X_Pos, Platform.Width);
   
   return 0;
}
//--------------------------------------------------------------------------------------------------------------