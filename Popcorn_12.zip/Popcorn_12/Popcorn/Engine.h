﻿#pragma once

#include <Windows.h>

#include "Border.h"
#include "Ball.h"

//--------------------------------------------------------------------------------------------------------------
enum EKey_Type: char
{
   EKT_Left,
   EKT_Right,
   EKT_Space
};
//--------------------------------------------------------------------------------------------------------------
const int Timer_ID = WM_USER + 1;
//--------------------------------------------------------------------------------------------------------------
class AsEngine;
class AsPlatform
{
public:
   AsPlatform();

   void Init();
   void Redraw_Platform(AsEngine *engine);
   void Draw(HDC hdc, RECT &paint_area, AsEngine *engine);

   static const int Circle_Size = 7;                      

   int X_Pos;
   int X_Pos_Step;
   int Width;

private:
   RECT Platform_Rect, Prev_Platform_Rect;
   HPEN Platgorm_Inner_Pen, Platgorm_Circle_Pen, Highligh_Pen; 
   HBRUSH Platgorm_Inner_Brush, Platgorm_Circle_Brush;

   static const int Platform_Height = 7;

   int Inner_Width;
};
//--------------------------------------------------------------------------------------------------------------
class AsEngine 
{
public:
   AsEngine();

   void Init_Engine(HWND hwnd);
   void Draw(HDC hdc, RECT &paint_area);
   int On_Key_Down(EKey_Type key_type);
   int On_Timer();
   
   HWND Hwnd;
   HPEN BG_Pen;
   HBRUSH BG_Brush;
      
private:
   ABall Ball;
   ALevel Level;
   AsPlatform Platform;
   AsBorder Border;
};
//--------------------------------------------------------------------------------------------------------------